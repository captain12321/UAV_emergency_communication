import pickle
import numpy as np
import matplotlib.pyplot as plt
f = open('None_rewards.pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content=pickle.load(f)
content.insert(0,-278)
x= np.linspace(0,25000,101)
#关闭文件
f.close()
f1=open('None_rewards_0.1.pkl','rb')
content1=pickle.load(f1)
content1.insert(0,-278)
x1= np.linspace(0,25000,101)
f1.close()

f2=open('None_rewards_0.2.pkl','rb')
content2=pickle.load(f2)
content2.insert(0,-278)
x2= np.linspace(0,25000,101)
f2.close()
plt.plot(x, content, label='lr=0.01', color='red',linewidth=2)#线1
plt.plot(x1, content1, label='lr=0.1', color='g',linewidth=2)#线2
plt.plot(x2, content2, label='lr=0.2', color='b',linewidth=2)#线3
plt.grid(color = 'lightgray', linestyle = '--', linewidth = 0.5)
plt.legend(loc=2) # 显示标签
plt.xlabel("Episodes") # 横轴名字
plt.ylabel("Reward") # 纵轴名字
plt.show()