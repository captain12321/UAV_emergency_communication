import pickle
import numpy as np
import matplotlib.pyplot as plt
f = open('Noneenergy_consumption_1(after).pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content=pickle.load(f)
split_sum1=[]
for i in range(0,20000,250):
    a=np.sum(content[i:i+250])
    split_sum1.append(a)
x= np.linspace(0,20000,80)
split_sum1=np.array(split_sum1)
#关闭文件
f.close()

# f = open('Noneenergy_consumption_1(before).pkl','rb')
# #使用load的方法将数据从pkl文件中读取出来
# content=pickle.load(f)
# #print(content)
# split_sum1_1=[]
# for i in range(0,20000,250):
#     a=np.sum(content[i:i+250])
#     split_sum1_1.append(a)
# x1= np.linspace(0,20000,80)
# split_sum1_1=np.array(split_sum1_1)
# #关闭文件
# f.close()

plt.figure(1)
plt.plot(x, split_sum1/250000, label='UAV1', color='red',linewidth=2)#线1
# plt.plot(x1, split_sum1_1/250000, label='UAV1_no_constraint', color='g',linewidth=2)#线1
plt.grid(color = 'lightgray', linestyle = '--', linewidth = 0.5)
plt.legend(loc=1) # 显示标签
plt.xlabel("Episodes") # 横轴名字
plt.ylabel("Energy consumption (KW)") # 纵轴名字
plt.show()

f = open('Noneenergy_consumption_2(after).pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content=pickle.load(f)
split_sum2=[]
for i in range(0,20000,250):
    a=np.sum(content[i:i+250])
    split_sum2.append(a)
x= np.linspace(0,20000,80)
split_sum2=np.array(split_sum2)
#关闭文件
f.close()

# f = open('Noneenergy_consumption_2(before).pkl','rb')
# #使用load的方法将数据从pkl文件中读取出来
# content=pickle.load(f)
# split_sum2_1=[]
# for i in range(0,20000,250):
#     a=np.sum(content[i:i+250])
#     split_sum2_1.append(a)
# x1= np.linspace(0,20000,80)
# split_sum2_1=np.array(split_sum2_1)
# #关闭文件
# f.close()

plt.figure(2)
plt.plot(x, split_sum2/250000, label='UAV2', color='red',linewidth=2)#线1
# plt.plot(x1, split_sum2_1/250000, label='UAV2_no_constraint', color='g',linewidth=2)#线1
plt.grid(color = 'lightgray', linestyle = '--', linewidth = 0.5)
plt.legend(loc=1) # 显示标签
plt.xlabel("Episodes") # 横轴名字
plt.ylabel("Energy consumption (KW)") # 纵轴名字
plt.show()