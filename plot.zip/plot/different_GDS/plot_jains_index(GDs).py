import pickle
import numpy as np
import matplotlib.pyplot as plt
f = open('Nonejains_index.pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content=pickle.load(f)
content.insert(0,0.9)
x= np.linspace(0,25000,100)
#关闭文件
f.close()

f = open('Nonejains_index(GD12).pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content1=pickle.load(f)
content1.insert(0,0.9)
x1= np.linspace(0,25000,100)
f.close()
#
f = open('Nonejains_index(GD16).pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content2=pickle.load(f)
content2.insert(0,0.9)
x2= np.linspace(0,25000,100)
f.close()


f = open('Nonejains_index(GD30).pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content3=pickle.load(f)
content3.insert(0,0.9)
x3= np.linspace(0,25000,100)
f.close()

plt.plot(x, content, label='GD=8', color='#ff7855',linewidth=2)#线1
plt.plot(x1, content1, label='GD=12', color='#a2a415',linewidth=2)#线2
plt.plot(x2, content2, label='GD=16', color='#5d21d0',linewidth=2)#线2
plt.plot(x3, content3, label='GD=30', color='#01a049',linewidth=2)#线2
plt.grid(color = 'lightgray', linestyle = '--', linewidth = 0.5)
plt.legend(loc=3) # 显示标签
plt.xlabel("Episodes") # 横轴名字
plt.ylabel("Jains Fairness Index") # 纵轴名字
plt.show()