import pickle
import numpy as np
import matplotlib.pyplot as plt
f = open('None_total_transmission_rate_64(25).pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content=pickle.load(f)
content.insert(0,0)
x= np.linspace(0,25000,100)
#关闭文件
f.close()

f = open('Nonemaddpg_total_transmission_rate.pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content1=pickle.load(f)
content1.insert(0,0)
x1= np.linspace(0,25000,100)
f.close()
#
f = open('Noneddpg_total_transmission_rate(ori_rew).pkl','rb')
#使用load的方法将数据从pkl文件中读取出来
content2=pickle.load(f)
content2.insert(0,0)
x2= np.linspace(0,25000,100)
f.close()

plt.plot(x, content, label='MUFC', color='red',linewidth=2)#线1
plt.plot(x1, content1, label='MADDPG', color='g',linewidth=2)#线2
plt.plot(x2, content2, label='DDPG', color='b',linewidth=2)#线2
plt.grid(color = 'lightgray', linestyle = '--', linewidth = 0.5)
plt.legend(loc=4) # 显示标签
plt.xlabel("Episodes") # 横轴名字
plt.ylabel("System Transmission Rate (Mbps)") # 纵轴名字
plt.show()