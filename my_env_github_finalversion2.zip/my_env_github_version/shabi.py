import numpy as np

a=np.square([1,2,3])
a=np.sum(a)
print(a)