# 2023-2-17，每save_rate个迭代后获取当前的状态，得到该episode所获得的传输量总值
if len(episode_rewards) >= 250 and len(episode_rewards) % arglist.save_rate < 100:
    for i, l in enumerate(env.world.landmarks):
        dists = [np.sqrt(np.sum(np.square(a.state.p_pos - l.state.p_pos))) for a in
                 env.world.agents]  # 1*agent_size list
        # 2023-2-20 修改，如果一个用户同时在两个无人机的服务区间内，则只算离得近的拿一个的传输量（这块默认两个无人机，服务半径0.25）
        if dists[0] < 0.25 and dists[1] < 0.25:
            if dists[0] > dists[1]:
                real_dist = dists[1]
                # 3-19
                env.world.agents[1].service_count += 1
                if env.world.agents[1].service_count <= 5:
                    transmitted += cal_total_output(real_dist)
                    landmark_transmission[i] += cal_total_output(real_dist)
                else:
                    transmitted += 0
                    landmark_transmission[i] += 0

            else:
                real_dist = dists[0]
                env.world.agents[0].service_count += 1
                if env.world.agents[0].service_count <= 5:
                    transmitted += cal_total_output(real_dist)
                    landmark_transmission[i] += cal_total_output(real_dist)
                else:
                    transmitted += 0
                    landmark_transmission[i] += 0

        elif dists[0] < 0.25 and dists[1] > 0.25:
            env.world.agents[0].service_count += 1
            if env.world.agents[0].service_count <= 5:
                transmitted += cal_total_output(dists[0])
                landmark_transmission[i] += cal_total_output(dists[0])
            else:
                transmitted += 0
                landmark_transmission[i] += 0
        elif dists[1] < 0.25 and dists[0] > 0.25:
            env.world.agents[1].service_count += 1
            if env.world.agents[1].service_count <= 5:
                transmitted += cal_total_output(dists[1])
                landmark_transmission[i] += cal_total_output(dists[1])
            else:
                transmitted += 0
                landmark_transmission[i] += 0
        else:
            transmitted += 0
            # landmark_transmission[i]+=0

for i, a in enumerate(env.world.agents):
    if a.service_count > 0:
        print(i, a.service_count)
    a.service_count = 0