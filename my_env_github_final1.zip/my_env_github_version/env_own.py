import argparse
import numpy as np
import tensorflow as tf
import time
import pickle
import math
import maddpg.common.tf_util as U
from maddpg.trainer.maddpg import MADDPGAgentTrainer
import tensorflow.contrib.layers as layers

def parse_args():
    parser = argparse.ArgumentParser("Reinforcement Learning experiments for multiagent environments")
    # Environment
    #parser.add_argument("--scenario", type=str, default="simple", help="name of the scenario script")
    parser.add_argument("--max-episode-len", type=int, default=30, help="maximum episode length")#default 25
    parser.add_argument("--num-episodes", type=int, default=20000, help="number of episodes")  #default is 60000
    parser.add_argument("--num-adversaries", type=int, default=0, help="number of adversaries")
    parser.add_argument("--good-policy", type=str, default="maddpg", help="policy for good agents")
    parser.add_argument("--adv-policy", type=str, default="maddpg", help="policy of adversaries")
    # Core training parameters
    parser.add_argument("--lr", type=float, default=1e-2, help="learning rate for Adam optimizer")
    parser.add_argument("--gamma", type=float, default=0.95, help="discount factor")
    parser.add_argument("--batch-size", type=int, default=1024, help="number of episodes to optimize at the same time")
    parser.add_argument("--num-units", type=int, default=64, help="number of units in the mlp")
    # Checkpointing
    parser.add_argument("--exp-name", type=str, default=None, help="name of the experiment")
    parser.add_argument("--save-dir", type=str, default="C:/Users/HP/Desktop/code_bishe/trainning_datas/policy/", help="directory in which training state and model should be saved") #/tmp/policy/
    parser.add_argument("--save-rate", type=int, default=1000, help="save model once every time this many episodes are completed") #1000次存一次
    parser.add_argument("--load-dir", type=str, default="", help="directory in which training state and model are loaded")
    # Evaluation
    parser.add_argument("--restore", action="store_true", default=False)
    parser.add_argument("--display", action="store_true", default=False)
    parser.add_argument("--benchmark", action="store_true", default=False)
    parser.add_argument("--benchmark-iters", type=int, default=100000, help="number of iterations run for benchmarking")
    parser.add_argument("--benchmark-dir", type=str, default="C:/Users/HP/Desktop/code_bishe/trainning_datas/benchmark/", help="directory where benchmark data is saved")
    parser.add_argument("--plots-dir", type=str, default="C:/Users/HP/Desktop/code_bishe/trainning_datas/plot/", help="directory where plot data is saved")
    return parser.parse_args()



#网络
def mlp_model(input, num_outputs, scope, reuse=False, num_units=64, rnn_cell=None):
    # This model takes as input an observation and returns values of all actions
    with tf.variable_scope(scope, reuse=reuse):
        out = input
        out = layers.fully_connected(out, num_outputs=num_units, activation_fn=tf.nn.relu)
        out = layers.fully_connected(out, num_outputs=num_units, activation_fn=tf.nn.relu)
        out = layers.fully_connected(out, num_outputs=num_outputs, activation_fn=None)
        return out

def make_env(benchmark=False):
    from simple_spread import Scenario
    from environment import MultiAgentEnv

    # load scenario from script
    scenario = Scenario()
    # create world
    world = scenario.make_world()
    # create multiagent environment
    if benchmark:
        env = MultiAgentEnv(world, scenario.reset_world, scenario.reward, scenario.observation, scenario.benchmark_data)
    else:
        env = MultiAgentEnv(world, scenario.reset_world, scenario.reward, scenario.observation)
    return env

def get_trainers(env, num_adversaries, obs_shape_n, arglist):
    trainers = []
    model = mlp_model
    trainer = MADDPGAgentTrainer
    for i in range(num_adversaries):
        trainers.append(trainer(
            "agent_%d" % i, model, obs_shape_n, env.action_space, i, arglist,
            local_q_func=(arglist.adv_policy=='ddpg')))
    for i in range(num_adversaries, env.n):
        trainers.append(trainer(
            "agent_%d" % i, model, obs_shape_n, env.action_space, i, arglist,
            local_q_func=(arglist.good_policy=='ddpg')))
    return trainers
 # 2023.2.16,2023.3.6,增加实际时隙时长
def cal_total_output(rew):
    covery_radius = 5661  # calculate using matlab with proper parameters
    Bk = 1 * 10 ** 6  # total bandwidth
    h = 100  # height of UAV
    fc = 2.4 * 10 ** 9
    N0 = 10 ** (-20)
    c = 3 * 10 ** 8
    a = 12.08
    b = 0.11
    LOS = 10 ** 0.3
    NLOS = 10 ** 2.3
    time_slot=75.48 #时长是75.48s
    # 计算当前状态SNR
    # 1.等比例获得实际距离
    practical_radius = (rew/0.25) * covery_radius #除以agent_size
    practical_distance = np.sqrt(h ** 2 + practical_radius ** 2)
    # print(practical_distance,end="\n")
    # 2.计算当前位置SNR
    loss_decay = (4 * math.pi * fc * practical_distance / c) ** 2
    Plos = 1 / (1 + a * math.exp(-b * (180 / math.pi * math.asin(h / practical_distance) - a)))
    pass_loss_practical = Plos * LOS * loss_decay + (1 - Plos) * NLOS * loss_decay
    pass_loss_practical_db = 10 * math.log10(pass_loss_practical)
    SNR_db = 140 - pass_loss_practical_db
    SNR = 10 ** (SNR_db / 10)
    # 3.计算传输速率
    C = Bk * math.log2(1 + SNR)*time_slot
    return C

def train(arglist, transmitted=0):
    with U.single_threaded_session():
        # Create environment
        env = make_env(arglist.benchmark)
        #print(arglist.benchmark,end="\n")
        # Create agent trainers
        obs_shape_n = [env.observation_space[i].shape for i in range(env.n)]
        num_adversaries = min(env.n, arglist.num_adversaries)
        trainers = get_trainers(env, num_adversaries, obs_shape_n, arglist)
        print('Using good policy {} and adv policy {}'.format(arglist.good_policy, arglist.adv_policy))

        # Initialize
        U.initialize()

        # Load previous results, if necessary
        if arglist.load_dir == "":
            arglist.load_dir = arglist.save_dir
        if arglist.display or arglist.restore or arglist.benchmark:
            print('Loading previous state...')
            U.load_state(arglist.load_dir)

        episode_rewards = [0.0]  # sum of rewards for all agents
        agent_rewards = [[0.0] for _ in range(env.n)]  # individual agent reward
        final_ep_rewards = []  # sum of rewards for training curve
        final_ep_ag_rewards = []  # agent rewards for training curve
        agent_info = [[[]]]  # placeholder for benchmarking info
        saver = tf.train.Saver()
        obs_n = env.reset()
        episode_step = 0
        train_step = 0
        t_start = time.time()

        #计数迭代次数
        episode_counter = 0
        print('Starting iterations...')
        while True:
            # get action
            action_n = [agent.action(obs) for agent, obs in zip(trainers,obs_n)]
            new_obs_n, rew_n, done_n, info_n = env.step(action_n)

            episode_step += 1
            done = all(done_n)
            terminal = (episode_step >= arglist.max_episode_len)
            # collect experience
            for i, agent in enumerate(trainers):
                agent.experience(obs_n[i], action_n[i], rew_n[i], new_obs_n[i], done_n[i], terminal)
            obs_n = new_obs_n

            for i, rew in enumerate(rew_n):
                #2023-01-08
                if i==0: #只加一遍传输总值
                    episode_rewards[-1] += rew #最后一位加上值
                agent_rewards[i][-1] += rew

            if done or terminal:
                obs_n = env.reset()
                episode_step = 0
                #2023_2_23
                episode_counter+=1
                episode_rewards.append(0)
                for a in agent_rewards:
                    a.append(0)
                agent_info.append([[]])
                # 2023-2-17 save_rate个迭代后计算总传输量,算后100个iteration的均值
                if len(episode_rewards)>1000 and len(episode_rewards) % arglist.save_rate ==100:
                    print("episodes:{},total transmission:{:.2f}MB".format(len(episode_rewards)-100, (transmitted/100)/(8*1000*1024)))
                    transmitted=0
                # #2023-2-23
                # if episode_counter==1000:
                #     print(max_move_distance)
                #2023-2-24 每个episode完成后服务计数归0
                for l in env.world.landmarks:
                    l.count=0


            train_step += 1


            # 2023-2-17，每save_rate个迭代后获取当前的状态，得到该episode所获得的传输量总值
            if len(episode_rewards)>=1000 and len(episode_rewards) % arglist.save_rate <100:
                for l in env.world.landmarks:
                    dists = [np.sqrt(np.sum(np.square(a.state.p_pos - l.state.p_pos))) for a in
                             env.world.agents]  # 1*agent_size list
                    # 2023-2-20 修改，如果一个用户同时在两个无人机的服务区间内，则只算离得近的拿一个的传输量（这块默认两个无人机，服务半径0.25）
                    if dists[0]<0.25 and dists[1]<0.25:
                        if dists[0]>dists[1]:
                            real_dist=dists[1]
                        else:
                            real_dist=dists[0]
                        transmitted+=cal_total_output(real_dist)
                    elif dists[0]<0.25 and dists[1]>0.25:
                        transmitted+=cal_total_output(dists[0])
                    elif dists[1]<0.25 and dists[0]>0.25:
                        transmitted+=cal_total_output(dists[1])
                    else:
                        transmitted+=0


            # for benchmarking learned policies (if benchmark sets true)
            if arglist.benchmark:
                for i, info in enumerate(info_n):
                    agent_info[-1][i].append(info_n['n'])
                if train_step > arglist.benchmark_iters and (done or terminal):
                    file_name = arglist.benchmark_dir + arglist.exp_name + '.pkl'
                    print('Finished benchmarking, now saving...')
                    with open(file_name, 'wb') as fp:
                        pickle.dump(agent_info[:-1], fp)
                    break
                continue

            # for displaying learned policies (if display sets true, and only display 1000 iterations
            if arglist.display:
                # if(len(episode_rewards)<4000):
                #     pass
                # else:
                if len(episode_rewards)%10==0:
                    time.sleep(0.1)
                    env.render()
                    continue


            # update all trainers, if not in display or benchmark mode
            loss = None
            for agent in trainers:
                agent.preupdate()
            for agent in trainers:
                loss = agent.update(trainers, train_step)



            # save model, display training output
            if terminal and (len(episode_rewards) % arglist.save_rate == 0):
                U.save_state(arglist.save_dir, saver=saver)


                # print statement depends on whether or not there are adversaries
                if num_adversaries == 0:
                    #modified on 2023-2-17
                    print("steps: {}, episodes: {}, mean episode reward: {},time: {}".format(
                        train_step, len(episode_rewards), np.mean(episode_rewards[-arglist.save_rate:]), round(time.time()-t_start, 3)))
                else:
                    print("steps: {}, episodes: {}, mean episode reward: {}, agent episode reward: {}, time: {}".format(
                        train_step, len(episode_rewards), np.mean(episode_rewards[-arglist.save_rate:]),
                        [np.mean(rew[-arglist.save_rate:]) for rew in agent_rewards], round(time.time()-t_start, 3)))
                t_start = time.time()
                # Keep track of final episode reward
                final_ep_rewards.append(np.mean(episode_rewards[-arglist.save_rate:]))
                for rew in agent_rewards:
                    final_ep_ag_rewards.append(np.mean(rew[-arglist.save_rate:]))

            # saves final episode reward for plotting training curve later
            if len(episode_rewards) > arglist.num_episodes:
                rew_file_name = str(arglist.plots_dir) + str(arglist.exp_name) + '_rewards.pkl'
                with open(rew_file_name, 'wb') as fp:
                    pickle.dump(final_ep_rewards, fp)
                agrew_file_name = str(arglist.plots_dir) + str(arglist.exp_name) + '_agrewards.pkl'
                with open(agrew_file_name, 'wb') as fp:
                    pickle.dump(final_ep_ag_rewards, fp)
                print('...Finished total of {} episodes.'.format(len(episode_rewards)))
                break

if __name__ == '__main__':
    arglist = parse_args()
    train(arglist)